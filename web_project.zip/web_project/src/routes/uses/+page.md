# Uses

**Here's some stuff I use**

- SvelteKit
- VS Code
- Emojis

```js
// JavaScript goes here,
// And will be syntax-highlighted!
```
